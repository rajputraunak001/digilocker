/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.digilocker;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class DataBase {
    
     static  String url  = "jdbc:mysql://localhost:3306/digilocker";  
    
    
    static void saveCustomer(int accountnumber, String name, String phone, String email, String aadharNumber, String panNumber, String address, String gender, String dob, String password) throws Exception {
       
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection( 
                url, "root", "root"); 
            
        Statement stmt = conn.createStatement(); 
           
        stmt.executeUpdate("insert into customers values ('"+accountnumber+"','"+name+"','"+phone+"','"+email+"','"+aadharNumber+"','"+panNumber+"','"+address+"','"+gender+"','"+dob+"','"+password+"')");
        
  
            // closing connection 
            conn.close(); 
    }
    
    static Boolean getCustomer(int accountnumber, String password) throws Exception{
       Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection( 
                url, "root", "root"); 
            
        Statement stmt = conn.createStatement(); 
        
        ResultSet rs = stmt.executeQuery("Select * from customers where accountnumber='"+accountnumber+"' AND password='"+password+"'");
        return rs.next();
        
        
        
    }
    
}
