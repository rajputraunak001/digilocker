/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.digilocker;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import java.util.Random;


public class Smssender {
    
     public static String getOtp() {

        Random random = new Random();
        int a = random.nextInt(10);
        int b = random.nextInt(10);
        int c = random.nextInt(10);
        int d = random.nextInt(10);

        String otp = a+""+b+""+c+""+d;
        return otp;

    }
  public static final String ACCOUNT_SID = "AC6c3c3569b230d7f91ec55b93d610380e";
  public static final String AUTH_TOKEN = "8731a6fca5e5a80f67cf9408dbc323b6";

    public static String sendSms(String toPhone)
    {

        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        String otp = getOtp();

        Message message = Message.creator(
                        new com.twilio.type.PhoneNumber("whatsapp:+91"+toPhone),
                        new com.twilio.type.PhoneNumber("whatsapp:+14155238886"),
                        "This is your otp., we are from digilocker "+otp)
                .create();

        System.out.println("Sms send success");
        return otp;
    }

    public static void sendSms(String toPhone,String msg)
    {

        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);


        Message message = Message.creator(
                        new com.twilio.type.PhoneNumber("whatsapp:+91"+toPhone),
                        new com.twilio.type.PhoneNumber("whatsapp:+14155238886"),
                        msg)
                .create();

        System.out.println("Sms send success");

    }
    
}
